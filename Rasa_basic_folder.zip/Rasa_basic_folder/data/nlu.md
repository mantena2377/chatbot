## intent:affirm
- ok,Bye
- great
- right, thank you
- correct
- Have a nice day
- thanks
- thanks

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- hi
- hi
- hello

## intent:restaurant_search
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines](cuisine:chinese) restaurants 
- show me a [mexican](cuisine) 
- i am looking for an [indian](cuisine) 
- search for restaurants
- search restaurants
- show me some restaurants
- find some restaurants
- I am looking for some restaurants
- anywhere in the [west](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [294328](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese](cuisine:chinese)
- [Mexican](cuisine)
- [American](cuisine)
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- in [Noida](location)
- in [Mumbai](location)
- in [Vizag](location)
- in [Hyderabad](location)
- in [Bangalore](location)
- [Pune](location)
- [Hyderanad](location)
- [Mumbai](location)
- [delhi](location)
- [Vizag](location)
- I am looking for some restaurants in [Mumbai](location)
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore](location)
- [mumbai](location)
- [Chinese](cuisine:chinese)
- show me restaurants
- [Noida](location)
- [Italian](cuisine)
- can you find me a [chinese](cuisine) restaurant
- [delhi](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location)
- I am looking for a [American](cuisine) restaurant in [Ajmer](location)
- [jabalpur](location)
- looking for a restaurant in range [Lesser than Rs. 300](price)
- looking for a place to eat in [pune](location)
- hello i am looking for a restaurant
- looking for a restaurant in [banglore](location)
- [indian](cuisine)
- [Lesser than Rs. 300](price)
- [Rs. 300 to 700](price)
- [More than 700](price)
- hello i am looking for [mexican](cuisine) restaurant
- restaurant in [bhilai](location)
- restaurants in [Hyderabad](location)
- restaurant in [chandigarh](location)
- [italian](cuisine) restaurant
- [south](cuisine) [indian](cuisine) restaurant
- [amravati](location)
- reataurant under [More than 700](price)
- restaurant in [Rs. 300 to 700](price)
- restaurant in budget [Lesser than Rs. 300](price)

## intent:email
- [mantena2377@gmail.com](email)
- [varmassce@gmail.com](email)
- please send to [mantena2377@gmail.com](email)
- yes send it to [gottupriya@gmail.com](email)
- yes email to [mantena2377@gmail.com](email)
- yeah send to [varmassce@gmail.com](email)
- send to [gottupriya@gmail.com](email)

## intent:email_response
- [Yes](email_response)
- [yes please](email_response)
- [No](email_response)
- [nopes](email_response)
- [yes](email_response)
- [no](email_response)
- [no](email_response) dont send

## synonym:4
- four

## synonym:Delhi
- New Delhi
- new deli
- delhi
- dilli

## synonym:Gurgaon
- Gurgon

## synonym:Mumbai
- mumbai
- bombay
- bombai

## synonym:Vizag
- vizag
- visakhapatnam
- visakapatnam

## synonym:Chennai
- chennai
- cennai
- chenai

## synonym:Hyderabad
- Hyd
- Hydarabad

## synonym:Delhi
- New Delhi
- new deli

## synonym:Nashik
- nasik

## synonym:Kolkata
- Calcutta

## synonym:Bhopal
- bopal

## synonym:bangalore
- Bengaluru

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:<300
- 150
- 100
- 200
- 250

## synonym:300-700
- 500
- 650
- 400-600
- 300-500
- 500-1000
- 400-700

## synonym:>700
- 1000
- 750
- 800
- 800-100

## synonym:mid
- moderate

## synonym:vegetarian
- veggie
- vegg

## regex:greet
- hey[^\s]*

## regex: email
- \w+@{1}[a-z]+.com

## regex:pincode
- [0-9]{6}
