
## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Noida"}
    - slot{"location": "Noida"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Noida"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "varmassce@gmail.com"}
    - slot{"email": "varmassce@gmail.com"}
    - action_send_email
    - slot{"email": "varmassce@gmail.com"}
    - utter_goodbye

## interactive_story_12
* greet
    - utter_greet
    - utter_ask_location
* restaurant_search{"location": "Patna"}
    - slot{"location": "Patna"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Patna"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "varmassce@gmail.com"}
    - slot{"email": "varmassce@gmail.com"}
    - action_send_email
    - slot{"email": "varmassce@gmail.com"}
    - utter_goodbye

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Gangtok"}
    - slot{"location": "Gangtok"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Noida"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "varmassce@gmail.com"}
    - slot{"email": "varmassce@gmail.com"}
    - action_send_email
    - slot{"email": "varmassce@gmail.com"}
    - utter_goodbye


## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"location": "Puducherry"}
    - slot{"location": "Puducherry"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Puducherry"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "varmassce@gmail.com"}
    - slot{"email": "varmassce@gmail.com"}
    - action_send_email
    - slot{"email": "varmassce@gmail.com"}
    - utter_goodbye

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Chandigarh"}
    - slot{"location": "Chandigarh"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Chandigarh"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "mantena2377@gmail.com"}
    - slot{"email": "mantena2377@gmail.com"}
    - action_send_email
    - slot{"email": "mantena2377@gmail.com"}
    - utter_goodbye

## interactive_story_5
* greet
    - utter_greet
* restaurant_search{"location": "nagpur"}
    - slot{"location": "nagpur"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "nagpur"}
    - utter_ask_email_response
* email_response{"email_response": "No"}
    - slot{"email_response": "No"}
    - utter_goodbye
* affirm
    - utter_affirm

## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Pune"}
    - slot{"location": "Pune"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Pune"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "mantena2377@gmail.com"}
    - slot{"email": "mantena2377@gmail.com"}
    - action_send_email
    - slot{"email": "mantena2377@gmail.com"}
    - utter_goodbye

## interactive_story_6
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Noida"}
    - slot{"location": "Noida"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Noida"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "gottupriya@gmail.com"}
    - slot{"email": "gottupriya@gmail.com"}
    - action_send_email
    - slot{"email": "gottupriya@gmail.com"}
    - utter_goodbye

## interactive_story_49
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Jaipur"}
    - slot{"location": "Jaipur"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "Lesser than Rs. 300"}
    - slot{"price": "Lesser than Rs. 300"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Jaipur"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "mantena2377@gmail.com"}
    - slot{"email": "mantena2377@gmail.com"}
    - action_send_email
    - slot{"email": "mantena2377@gmail.com"}
    - utter_goodbye

## interactive_story_4
* greet
    - utter_greet
    - utter_ask_location
* restaurant_search{"location": "Ooty"}
    - slot{"location": "Ooty"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Ooty"}
    - utter_ask_email_response
* email_response{"email_response": "No"}
    - slot{"email_response": "No"}
    - utter_goodbye

## interactive_story_6
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bhopal"}
    - slot{"location": "Bhopal"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "North Indian"}
    - slot{"cuisine": "North Indian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Bhopal"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "gottupriya@gmail.com"}
    - slot{"email": "gottupriya@gmail.com"}
    - action_send_email
    - slot{"email": "gottupriya@gmail.com"}
    - utter_goodbye

## interactive_story_7
* restaurant_search{"location": "Noida"}
    - slot{"location": "Noida"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Noida"}
    - utter_ask_email_response
* email_response{"email_response": "No"}
    - slot{"email_response": "No"}
    - utter_goodbye


## interactive_story_59
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "agra"}
    - slot{"location": "agra"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "agra"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "varmassce@gmail.com"}
    - slot{"email": "varmassce@gmail.com"}
    - action_send_email
    - slot{"email": "varmassce@gmail.com"}
    - utter_goodbye

## interactive_story_59
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Coimbatore"}
    - slot{"location": "Coimbatore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "agra"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "varmassce@gmail.com"}
    - slot{"email": "varmassce@gmail.com"}
    - action_send_email
    - slot{"email": "varmassce@gmail.com"}
    - utter_goodbye


## interactive_story_60
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "jabalpur"}
    - slot{"location": "jabalpur"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - utter_ask_price
* restaurant_search{"price": "Lesser than Rs. 300"}
    - slot{"price": "Lesser than Rs. 300"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "jabalpur"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "mantena2377@gmail.com"}
    - slot{"email": "mantena2377@gmail.com"}
    - action_send_email
    - slot{"email": "mantena2377@gmail.com"}
    - utter_goodbye


## interactive_story_1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Vizag"}
    - slot{"location": "Vizag"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - utter_ask_price
* restaurant_search{"price": "Lesser than Rs. 300"}
    - slot{"price": "Lesser than Rs. 300"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Vizag"}
    - utter_ask_email_response
* email_response{"email_response": "No"}
    - slot{"email_response": "No"}
    - utter_goodbye

## interactive_story_65
* restaurant_search{"location": "ghaziabad"}
    - slot{"location": "ghaziabad"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - utter_ask_price
* restaurant_search{"price": "Lesser than Rs. 300"}
    - slot{"price": "Lesser than Rs. 300"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "ghaziabad"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "gottupriya@gmail.com"}
    - slot{"email": "gottupriya@gmail.com"}
    - action_send_email
    - slot{"email": "gottupriya@gmail.com"}
    - utter_goodbye

## interactive_story_67
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "gurgaon"}
    - slot{"location": "gurgaon"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_price
* restaurant_search{"price": "Lesser than Rs. 300"}
    - slot{"price": "Lesser than Rs. 300"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "gurgaon"}
    - utter_ask_email_response
* email_response{"email_response": "Yes"}
    - slot{"email_response": "Yes"}
    - utter_ask_email
* email{"email": "mantena2377@gmail.com"}
    - slot{"email": "mantena2377@gmail.com"}
    - action_send_email
    - slot{"email": "mantena2377@gmail.com"}
    - utter_goodbye


## interactive_story_69
* greet
    - utter_greet
    - utter_ask_location
* restaurant_search{"location": "nagpur"}
    - slot{"location": "nagpur"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "South Indian"}
    - slot{"cuisine": "South Indian"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "nagpur"}
    - utter_ask_email_response
* email_response{"email_response": "No"}
    - slot{"email_response": "No"}
    - utter_goodbye

## interactive_story_12
* greet
    - utter_greet
    - utter_ask_location
* restaurant_search{"location": "Patna"}
    - slot{"location": "Patna"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_price
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Patna"}
    - utter_ask_email_response
* email_response{"email_response": "No"}
    - slot{"email_response": "No"}
    - utter_goodbye

## interactive_story_44
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Kanpur"}
    - slot{"location": "Kanpur"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - utter_ask_price
* restaurant_search{"price": "Rs. 300 to 700"}
    - slot{"price": "Rs. 300 to 700"}
    - action_check_loc
    - slot{"check_location": "Found"}
    - action_search_restaurants
    - slot{"location": "Kanpur"}
    - utter_ask_email_response
* email_response{"email_response": "No"}
    - slot{"email_response": "No"}
    - utter_goodbye





