from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action,Tracker
from rasa_sdk.events import SlotSet
import pandas as pd
import json
import smtplib

ZomatoData = pd.read_csv('zomato.csv')
ZomatoData = ZomatoData.drop_duplicates().reset_index(drop=True)
WeOperate = ['New Delhi', 'Gurgaon', 'Noida', 'Faridabad', 'Allahabad', 'Bhubaneshwar', 'Mangalore', 'Mumbai', 'Ranchi', 'Patna', 'Mysore', 'Aurangabad', 'Amritsar', 'Puducherry', 'Varanasi', 'Nagpur', 'Vadodara', 'Dehradun', 'Vizag', 'Agra', 'Ludhiana', 'Kanpur', 'Lucknow', 'Surat', 'Kochi', 'Indore', 'Ahmedabad', 'Coimbatore', 'Chennai', 'Guwahati', 'Jaipur', 'Hyderabad', 'Bangalore', 'Nashik', 'Pune', 'Kolkata', 'Bhopal', 'Goa', 'Chandigarh', 'Ghaziabad', 'Ooty', 'Gangtok', 'Shimla']

def RestaurantSearch(City,Cuisine,Average_Cost_for_two):
     #find budget boundary
	minBudget, maxBudget = getMinMaxBudget(Average_Cost_for_two);
	TEMP = ZomatoData[(ZomatoData['Cuisines'].apply(lambda x: Cuisine.lower() in x.lower())) & (ZomatoData['City'].apply(lambda x: City.lower() in x.lower())) & (ZomatoData['Average_Cost_for_two'] >= minBudget) & (ZomatoData['Average_Cost_for_two'] <= maxBudget)]
	return TEMP[['Restaurant Name','Address','Average_Cost_for_two','Aggregate rating']]

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'

	def run(self, dispatcher, tracker, domain):
		#config={ "user_key":"f4924dc9ad672ee8c4f8c84743301af5"}
		location = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price = tracker.get_slot('price')
		results = RestaurantSearch(City=location,Cuisine=cuisine,Average_Cost_for_two=price)
		response=""
		if results.shape[0] == 0:
			response= "no results"
		else:
			results = results.sort_values(['Aggregate rating'],ascending=False).head(5)
			for restaurant in results.iterrows():
				restaurant = restaurant[1]
				response=response + F"Found {restaurant['Restaurant Name']} in {restaurant['Address']} has been rated {restaurant['Aggregate rating']} \n\n"
				
		dispatcher.utter_message("-"+response)
		return [SlotSet('location',location)]

class ActionSendMail(Action):
	def name(self):
		return 'action_send_email'

	def run(self, dispatcher, tracker, domain):
		MailID = tracker.get_slot('email')
		location = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		price = tracker.get_slot('price')
		results = RestaurantSearch(City=location,Cuisine=cuisine,Average_Cost_for_two=price)
		response=""
		if results.shape[0] == 0:
			response= "no results"
		else:
			results = results.sort_values(['Aggregate rating'],ascending=False).head(10)
			for restaurant in results.iterrows():
				restaurant = restaurant[1]
				response=response + F"Found {restaurant['Restaurant Name']} in {restaurant['Address']} rated {restaurant['Aggregate rating']} with avg cost {restaurant['Average_Cost_for_two']} \n\n"
		sendmail(MailID,response)
		dispatcher.utter_message("Email sent")
		return [SlotSet('email',MailID)]


class ActionCheckLocation(Action):
	def name(self):
		return 'action_check_loc'
	def run(self, dispatcher, tracker, domain):
		location = tracker.get_slot('location')
		res = ValidateLocation(location)
		if (res == 'Not Found'):
			dispatcher.utter_message("Invalid Location.We Dnot operate to Tier-3 cities")
		return [SlotSet('check_location',res)]
    



def sendmail(toadd,message):
    fromadd = 'samplemail1142@gmail.com'
    server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
    server.login(fromadd, "nmsjhx652#")
    server.sendmail(fromadd, toadd, message)

def ValidateLocation(City):
    string = ""
    if City in WeOperate:
        string = 'Found'
    else:
        string = 'Not Found'
    return string  
    
    
def getMinMaxBudget(price):
    minBudget = 0
    maxBudget = 5000;
    
    if price == 'Lesser than Rs. 300':
        maxBudget = 300
    elif price == 'Rs. 300 to 700':
        minBudget = 300
        maxBudget = 700
    else:
        minBudget = 700
    return [minBudget, maxBudget]
